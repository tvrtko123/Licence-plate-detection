# License Plate > 2024-02-02 12:09am
https://universe.roboflow.com/myplate/license-plate-plww7

Provided by a Roboflow user
License: CC BY 4.0

